<?php
/**
* Plugin Name: My Dictionary
* Plugin URI: https://eduvallve.com
* Description: Smooth WordPress plugin for multilingual sites.
* Version: 0.1
* Author: eduvallve
* Author URI: https://eduvallve.com
**/

/**
 * Functions (Front-office)
 */

require_once 'functions/functions.php';

/**
 * Admin page (Back-office)
 */

require_once 'admin/admin.php';

?>