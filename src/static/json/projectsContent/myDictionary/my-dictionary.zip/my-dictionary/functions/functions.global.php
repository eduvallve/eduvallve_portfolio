<?php

function showFunctionFired($name) {
    // This function is used for debugging purposes only
    // It shows when a function is fired
    // Uncomment the line below to see the function calls
    // echo "<b style='color:blue'>$name</b><br> ";
}

?>