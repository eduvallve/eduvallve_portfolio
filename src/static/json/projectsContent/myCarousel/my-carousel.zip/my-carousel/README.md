# My Carousel – Custom WordPress Carousel Plugin

A lightweight custom **WordPress plugin** that lets you create, manage, and display image/content carousels on your WordPress site. This plugin provides an easy way to add responsive carousel sliders to posts, pages, or widget areas.

## 🚀 Features

* Create unlimited carousel instances
* Supports image and content slides
* Simple shortcode usage
* Responsive design for all screen sizes
* Lightweight and dependency-free

> Optional: add more feature details here based on your code.

## 📦 Installation

### From GitHub

1. Clone the repository:
   ```plaintext
   git clone https://github.com/eduvallve/my-carousel.git
   ```
2. Upload the `my-carousel` folder to your WordPress plugins directory:
   ```plaintext
   wp-content/plugins/
   ```
3. Activate the plugin from the **Plugins** menu in WordPress.

### From WordPress Dashboard

1. Go to **Plugins → Add New**
2. Click **Upload Plugin**
3. Choose the ZIP file and click **Install Now**
4. Activate the plugin

## 🧩 Usage

### Shortcode

Add the following shortcode to any post or page to display your carousel:

```
[my-carousel id="123"]
```

Replace `"123"` with the ID of your carousel.

> *Add any additional shortcode attributes and how they work (e.g., autoplay, speed, etc.) here, if applicable.*

### Template Tag

You can also display a carousel in your theme template:

```php
<?php echo do_shortcode('[my-carousel id="123"]'); ?>
```

## ❓ Support

If you encounter any problems or have questions, open an issue on this GitHub repository.

## 📜 License

This project is open-source and released under the **MIT License**.
